How to run:
-----------
Open SICStus and type:
> consult('/home/henrique/git/feup-plog/project/eximo.pl').
> eximo.